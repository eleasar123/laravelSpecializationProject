<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="cpl-3 p-5">
            <img src="<?php echo e($user->profiles->profileImage()); ?>" class="w-100 rounded-circle" style="height: 180px;">
        </div>
        <div class="col-9 p-5">

            <div class="d-flex justify-content-between align-items-baseline">

                <div class = "d-flex align-items-center pb-4"> <!--padding bottom 4 -->
                    <h1><?php echo e($user->username); ?></h1> <!--Mushtash syntax-->

                    <follow-button user-id="<?php echo e($user->id); ?>" follows="<?php echo e($follows); ?>"></follow-button>
                </div>
                
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $user->profiles)): ?>
                    <a href="/p/create" class="btn btn-primary">Add New Post</a>
                <?php endif; ?>

            </div>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $user->profiles)): ?>
                <a href="/profile/<?php echo e($user->id); ?>/edit">Edit Profile</a>
            <?php endif; ?>

            <div class= "d-flex">
                <div class="pr-5"><strong><?php echo e($user->posts->count()); ?></strong> posts</div>
                <div class="pr-5"><strong><?php echo e($user->profiles->followers->count()); ?></strong> followers</div>
                <div class="pr-5"><strong><?php echo e($user->following->count()); ?></strong> following</div>
            </div>

            

            <div class="pt-4 font-weight-bold"><?php echo e($user->profiles->title); ?></div>
            <div><?php echo e($user->profiles->description); ?></div>
            <div><a href="#"><?php echo e($user->profiles->url); ?></a></div>

        </div>
    </div>

    <div class="row">

    <?php $__currentLoopData = $user->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-4 pb-3">
            <a href="/p/<?php echo e($post->id); ?>">
            <img src="/storage/<?php echo e($post->image); ?>" class="w-100">
            </a>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Public\Public Documents\xampp\htdocs\PHP_ALL_IN\laravel-crud-app\resources\views/profiles/index.blade.php ENDPATH**/ ?>